export const Roles = {
  General: 'General',
  Supervisor: 'Supervisor',
  HSE: 'HSE',
  Other: 'Other'
};
