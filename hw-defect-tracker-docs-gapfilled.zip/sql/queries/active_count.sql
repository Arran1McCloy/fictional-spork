SELECT COUNT(*) AS count FROM "defectData" WHERE status='active';
