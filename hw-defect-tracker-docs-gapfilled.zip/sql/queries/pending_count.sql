SELECT COUNT(*) AS count FROM "defectData" WHERE status='pending';
