# Departments (canonical)

- Facilities
- General
- HSE
- Mechanical Fitter
- Operations
- Other
- Pipe Fitter
- Rigger
- Slinger
- Steel work - welding
- Supervisor
- active
- high
- low
- medium
- pending
- resolved (fixed)
- resolved (irreparable)
