# UI Components — Charts (ECharts options)

Below are option objects auto-extracted from the Appsmith export. Review and edit if needed.

_No ECharts options were detected automatically. Please paste your desired `option` objects here._


## Extracted Screenshots
- Signing up and creating a defect report__image1.png
- Signing up and creating a defect report__image4.png
- Signing up and creating a defect report__image5.png
- Signing up and creating a defect report__image3.png
- Signing up and creating a defect report__image2.png
- Using the dashboard and managing defects__image1.png
- Using the dashboard and managing defects__image2.png
- Using the dashboard and managing defects__image3.png
- Using the dashboard and managing defects__image4.png
- Using the dashboard and managing defects__image11.png
- Using the dashboard and managing defects__image7.png
- Using the dashboard and managing defects__image8.png
- Using the dashboard and managing defects__image9.png
- Using the dashboard and managing defects__image10.png
- Using the dashboard and managing defects__image5.png
- Using the dashboard and managing defects__image6.png
